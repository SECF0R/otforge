<#
.SYNOPSIS
    Universal Folder Unlocker and Config Encodings Scrub with Root Verification.
.DESCRIPTION
    Dynamically verifies the root folder path from where the script is executed.
#>
$scriptDir = $PSScriptRoot
if ($scriptDir.EndsWith("otforge_portable_toolkit")) { 
    $targetPath = Split-Path $scriptDir 
} else {
    $targetPath = $scriptDir
}

if (-not (Test-Path "$targetPath\packages\app")) {
    Write-Host "? Error: Script is not running inside an otforge directory structure!" -ForegroundColor Red
    Write-Host "Current detected path: $targetPath" -ForegroundColor Yellow
    Exit
}

Write-Host "?? Verified Root Location: $targetPath" -ForegroundColor Green
Write-Host "??? Removing Read-Only restrictions from root path..." -ForegroundColor Cyan
attrib -r -s -h "$targetPath\*.*" /s /d

$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
Write-Host "?? Assigning full file control parameters to: $currentUser" -ForegroundColor Cyan
takeown.exe /F "$targetPath" /R /D Y /A /SKIPSL | Out-Null
icacls.exe "$targetPath" /grant "${currentUser}:(OI)(CI)F" /T /Q /C

Write-Host "?? Scrubbing hidden text encoding BOM profiles..." -ForegroundColor Cyan
$configFiles = Get-ChildItem -Path "$targetPath\package.json", "$targetPath\tsconfig*.json", "$targetPath\packages\*\package.json", "$targetPath\packages\*\tsconfig*.json" -ErrorAction SilentlyContinue
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

foreach ($file in $configFiles) {
    $cleanText = [System.IO.File]::ReadAllText($file.FullName)
    [System.IO.File]::WriteAllText($file.FullName, $cleanText, $utf8NoBom)
}
Write-Host "? Permissions unlocked and BOM profiles cleaned universally!" -ForegroundColor Green

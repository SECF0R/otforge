<#
.SYNOPSIS
    Universal Sub-Workspace Compiler and Launch Sync Hook with Root Verification.
#>
$scriptDir = $PSScriptRoot
if ($scriptDir.EndsWith("otforge_portable_toolkit")) { $targetPath = Split-Path $scriptDir } else { $targetPath = $scriptDir }

if (-not (Test-Path "$targetPath\packages\app")) {
    Write-Host "? Error: Invalid root path detected: $targetPath" -ForegroundColor Red
    Exit
}

Write-Host "?? Verified Root Location: $targetPath" -ForegroundColor Green
Write-Host "??? Flushing compiler layers..." -ForegroundColor Cyan
$env:ELECTRON_OVERRIDE_DIST_PATH = $null
$env:ELECTRON_PATH = $null

Remove-Item -Recurse -Force "$targetPath\packages\app\out\", "$targetPath\packages\app\.vite\", "$targetPath\packages\orchestrator\dist\" -ErrorAction SilentlyContinue

Push-Location $targetPath
npm run build --workspace=@otforge/schema
npm run build --workspace=@otforge/orchestrator

Write-Host "?? Launching localized application workspace engine!" -ForegroundColor Green
npm run dev
Pop-Location

<#
.SYNOPSIS
    Dynamic User Electron Cache Finder and Extractor with Root Verification.
#>
$scriptDir = $PSScriptRoot
if ($scriptDir.EndsWith("otforge_portable_toolkit")) { $targetPath = Split-Path $scriptDir } else { $targetPath = $scriptDir }

if (-not (Test-Path "$targetPath\packages\app")) {
    Write-Host "? Error: Invalid root path detected: $targetPath" -ForegroundColor Red
    Exit
}

Write-Host "?? Verified Root Location: $targetPath" -ForegroundColor Green
Write-Host "?? Locating localized AppData framework caches..." -ForegroundColor Cyan
$distDir = "$targetPath\node_modules\electron\dist"
if (!(Test-Path $distDir)) { New-Item -ItemType Directory -Path $distDir -Force | Out-Null }

$dynamicCachePath = Join-Path $env:USERPROFILE "AppData\Local\electron\Cache\"
$foundExe = Get-ChildItem -Path $dynamicCachePath -Recurse -Filter "electron.exe" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName -First 1

if ($foundExe) {
    $sourceFolder = Split-Path $foundExe
    Write-Host "?? Extracting clean engine structures out of user cache: $sourceFolder" -ForegroundColor Green
    Copy-Item -Path "$sourceFolder\*" -Destination $distDir -Recurse -Force
    [System.IO.File]::WriteAllText("$targetPath\node_modules\electron\path.txt", "electron.exe")
    Write-Host "?? Absolute Success! Local framework paths successfully populated for user: $env:USERNAME" -ForegroundColor Green
} else {
    Write-Host "? Active cache profile is currently clear. Web browser delivery zip framework required." -ForegroundColor Red
}

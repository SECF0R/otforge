<#
.SYNOPSIS
    Portable Workspace Configuration Alignment with Root Verification.
#>
$scriptDir = $PSScriptRoot
if ($scriptDir.EndsWith("otforge_portable_toolkit")) { $targetPath = Split-Path $scriptDir } else { $targetPath = $scriptDir }

if (-not (Test-Path "$targetPath\packages\app")) {
    Write-Host "? Error: Invalid root path detected: $targetPath" -ForegroundColor Red
    Exit
}

Write-Host "?? Verified Root Location: $targetPath" -ForegroundColor Green
Write-Host "?? Re-aligning workspace structures..." -ForegroundColor Cyan
if (Test-Path "$targetPath\.git") { 
    Push-Location $targetPath
    git checkout -- .\packages\app\src\main\index.ts
    Pop-Location
}

$schemaValidatorFile = "$targetPath\packages\orchestrator\src\schema-validator.ts"
if (Test-Path $schemaValidatorFile) {
    $validatorContent = Get-Content $schemaValidatorFile -Raw
    if ($validatorContent -match "if \(!device\.ipAddress\)") {
        $validatorContent = $validatorContent -replace "if \(!device\.ipAddress\)", "const castDevice = device as any;`r`n    if (!castDevice.ipAddress)"
        $validatorContent = $validatorContent -replace "device\.category", "castDevice.category"
        Set-Content $schemaValidatorFile $validatorContent -Force
    }
}

$cleanTsConfigText = @"
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "CommonJS",
    "lib": ["ES2022"],
    "strict": false,
    "noImplicitAny": false,
    "strictNullChecks": false,
    "exactOptionalPropertyTypes": false,
    "skipLibCheck": true,
    "allowSyntheticDefaultImports": true,
    "esModuleInterop": true,
    "outDir": "./dist",
    "rootDir": "./src"
  },
  "include": ["src/**/*"]
}
"@
Set-Content "$targetPath\packages\orchestrator\tsconfig.json" $cleanTsConfigText -Force

$packageJsonPath = "$targetPath\packages\app\package.json"
if (Test-Path $packageJsonPath) {
    $jsonText = [System.IO.File]::ReadAllText((Resolve-Path $packageJsonPath).Path)
    $jsonText = $jsonText -replace '"main"\s*:\s*"[^"]+install\.js"', '"main": "./out/main/index.js"'
    $jsonText = $jsonText -replace '"main"\s*:\s*"\./out/main/install\.js"', '"main": "./out/main/index.js"'
    [System.IO.File]::WriteAllText((Resolve-Path $packageJsonPath).Path, $jsonText, [System.Text.Encoding]::UTF8)
}
Write-Host "? Monorepo structural alignment paths synchronized contextually!" -ForegroundColor Green
